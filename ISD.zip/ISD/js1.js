// Wait for the document to load
document.addEventListener('DOMContentLoaded', function() {
    // Get the toggle label and drop input
    var toggleLabel = document.querySelector('.toggle');
    var dropInput = document.getElementById('drop');
  
    // Function to handle menu toggle
    function toggleMenu() {
      dropInput.checked = !dropInput.checked;
    }
  
    // Add event listener to the toggle label
    toggleLabel.addEventListener('click', toggleMenu);
  });


  // Add an event listener to all services boxes
const serviceBoxes = document.querySelectorAll('.services-box');
serviceBoxes.forEach(box => {
  box.addEventListener('click', () => {
    // Toggle the 'active' class on the clicked box
    box.classList.toggle('active');
  });
});

  