$(document).ready(function() {
    $("form").submit(function(event) {
      event.preventDefault(); // Prevent the default form submission

      // Display an alert message
      alert("Message submitted!");

      // You can add additional code here to handle the form submission, such as sending the data to a server using AJAX

      // Reset the form fields
      $(this).trigger("reset");
    });
  });