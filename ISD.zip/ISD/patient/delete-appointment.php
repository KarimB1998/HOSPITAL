<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
        header("location: ../login.php");
    }

}else{
    header("location: ../login.php");
}

if($_GET){
    
    include("../connection.php");
    $id=$_GET["id"];
    
    // Fetch the schedule ID associated with the canceled appointment
    $scheduleQuery = "SELECT scheduleid FROM appointment WHERE appoid='$id'";
    $scheduleResult = $database->query($scheduleQuery);
    
    if ($scheduleResult->num_rows > 0) {
        $scheduleRow = $scheduleResult->fetch_assoc();
        $scheduleId = $scheduleRow['scheduleid'];

        // Delete the appointment
        $deleteQuery = "DELETE FROM appointment WHERE appoid='$id'";
        $deleteResult = $database->query($deleteQuery);

        if ($deleteResult) {
            // Increment nop by 1 for the associated schedule
            $updateQuery = "UPDATE schedule SET nop = nop + 1 WHERE scheduleid = $scheduleId";
            $updateResult = $database->query($updateQuery);

            header("location: appointment.php");
        } else {
            header("location: appointment.php?action=cancel-failed");
        }
    } else {
        header("location: appointment.php?action=cancel-failed");
    }
}
?>





    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    
    if($_GET){
        
        include("../connection.php");
        $id=$_GET["id"];
        $sql= $database->query("delete from appointment where appoid='$id';");
        header("location: appointment.php");}
    

