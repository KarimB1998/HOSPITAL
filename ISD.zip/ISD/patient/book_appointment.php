<?php
session_start();

if (isset($_SESSION["user"])) {
    if ($_SESSION["user"] == "" || $_SESSION['usertype'] != 'p') {
        header("location: ../login.php");
    }
} else {
    header("location: ../login.php");
}

if ($_POST) {
    // Import database
    include("../connection.php");

    // Get the session ID from the form
    $sessionID = $_POST["sessionID"];

    // Check if the session exists and has nop=1
    $checkQuery = "SELECT * FROM schedule WHERE scheduleid = $sessionID AND nop = 1";
    $checkResult = $database->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Session with nop=1 exists, allow the patient to book the appointment

        // Get patient ID from the session
        $patientID = $_SESSION["patientID"];

        // Insert appointment details into the database
        $insertQuery = "INSERT INTO appointment (pid, scheduleid) VALUES ($patientID, $sessionID)";
        $database->query($insertQuery);

        // Remove the session from the patient's dashboard
        $deleteQuery = "DELETE FROM schedule WHERE scheduleid = $sessionID";
        $database->query($deleteQuery);

        header("location: dashboard.php?action=appointment-booked");
    } else {
        // Session with nop=1 does not exist or already booked by another patient
        header("location: dashboard.php?action=session-unavailable");
    }
}
?>
