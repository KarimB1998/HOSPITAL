<?php
session_start();

if (isset($_SESSION["user"])) {
    if ($_SESSION["user"] == "" || $_SESSION['usertype'] != 'p') {
        header("location: ../login.php");
    } else {
        $useremail = $_SESSION["user"];
    }
} else {
    header("location: ../login.php");
}

// import database
include("../connection.php");
$userrow = $database->query("select * from patient where pemail='$useremail'");
$userfetch = $userrow->fetch_assoc();
$userid = $userfetch["pid"];
$username = $userfetch["pname"];

if ($_POST) {
    if (isset($_POST["booknow"])) {
        $apponum = $_POST["apponum"];
        $scheduleid = $_POST["scheduleid"];
        $date = $_POST["date"];

        $checkQuery = "SELECT * FROM schedule WHERE scheduleid = $scheduleid AND nop IN  (1, 2, 3, 4, 5, 6, 7, 8, 9) ";
        $checkResult = $database->query($checkQuery);

        if ($checkResult->num_rows > 0) {
            $sql2 = "INSERT INTO appointment(pid, apponum, scheduleid, appodate) VALUES ($userid, $apponum, $scheduleid, '$date')";
            $result = $database->query($sql2);

            // Update session responsible for the doctor
            $updateQuery = "UPDATE schedule SET nop = nop - 1 WHERE scheduleid = $scheduleid";
            $updateResult = $database->query($updateQuery);

            header("location: appointment.php?action=booking-added&id=".$apponum."&titleget=none");
        } else {
            
            header("location: appointment.php?action=booking-notadded&id=".$apponum."&titleget=none");
        }
    }elseif (isset($_GET["id"])) {
        $id = $_GET["id"];

        // Fetch the schedule ID associated with the canceled appointment
        $scheduleQuery = "SELECT scheduleid FROM appointment WHERE appoid='$id'";
        $scheduleResult = $database->query($scheduleQuery);

        if ($scheduleResult->num_rows > 0) {
            $scheduleRow = $scheduleResult->fetch_assoc();
            $scheduleId = $scheduleRow['scheduleid'];

            // Delete the appointment
            $deleteQuery = "DELETE FROM appointment WHERE appoid='$id'";
            $deleteResult = $database->query($deleteQuery);

            if ($deleteResult) {
                // Increment nop by 1 for the associated schedule
                $updateQuery = "UPDATE schedule SET nop = nop + 1 WHERE scheduleid = $scheduleId";
                $updateResult = $database->query($updateQuery);

                header("location: appointment.php");
            } 
    }
}
}
?>
















