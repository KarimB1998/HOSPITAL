<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
	<title> Blog Details </title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Be Clinic Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	 <script src="js.js"></script>

	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link href="css/single.css" rel='stylesheet' type='text/css' />
	<!-- single page -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Mukta:200,300,400,500,600,700,800&amp;subset=devanagari,latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->
	<style>
		.user-info {
  text-align: right;
}

.user-avatar {
  border-radius: 50%;
  width: 10%;
}

.user-title {
  margin: 0;
  font-weight: bold;
}

.user-email {
  margin: 0;
}

.logout-btn {
  margin-top: 10px;
}
/* Custom styles for user info table */

.user-info {
  display: flex;
  align-items: center;
}

.user-avatar {
  width: 10%;
  margin-right: 10px;
}

.user-title {
  margin-left: 0;
  font-size: 14px;
  font-weight: bold;
}

.user-email {
  margin: 0;
  font-size: 12px;
  color: #999;
}

.logout-btn {
  padding: 8px 16px;
  font-size: 14px;
  background-color: #2196f3;
  color: #fff;
  border: none;
  cursor: pointer;
  transition: background-color 0.3s;
}

.logout-btn:hover {
  background-color: #0d8bf5;
}
.text-right {
  text-align: right;
}
	</style>
</head>

<body>
<?php

//learn from w3schools.com

session_start();

if(isset($_SESSION["user"])){
	if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
		header("location: ../login.php");
	}else{
		$useremail=$_SESSION["user"];
	}

}else{
	header("location: ../login.php");
}


//import database
include("../connection.php");
$userrow = $database->query("select * from patient where pemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["pid"];
$username=$userfetch["pname"];


//echo $userid;
//echo $username;

?>
	<!-- main -->
	<div id="home">
		<!-- top header -->
		<header>
			<div class="top-bar py-3">
				<div class="container">
					<div class="row">
						<div class="col-xl-5 col-lg-6 col-md-8 top-social-agile text-lg-left text-center">
							<div class="row">
								<div class="col-4 header-top_w3layouts">
									<p class="text-bl">
										<span class="fa fa-map-marker mr-2"></span>LEBANON
									</p>
								</div>
								<div class="col-4 header-top_w3layouts">
									<p class="text-bl">
										<span class="fa fa-phone mr-2"></span>+961
									</p>
								</div>
								<!-- social icons -->
								<ul class="col-4 top-right-info">
									<li>
										<a href="https://www.facebook.com/karim.borshalli/">
											<span class="fa fa-facebook-f"></span>
										</a>
									</li>
									<li class="mx-3">
										<a href="https://www.instagram.com/karimborshalli/">
											<span class="fa fa-instagram"></span>
										</a>
									</li>
									
								</ul>
								<!-- //social icons -->
							</div>
						</div>
						<div class="col-xl-7 col-lg-6 col-md-4 top-social-agile text-md-right text-center mt-md-0 mt-2">
							<div class="row">
								<div class="offset-xl-6 offset-lg-4">
								</div>
								<tr>
    <td class="user-info">
        <table border="0">
            <tr>
                <td>
				<a href="index.php"><img src="../img/user.png" alt="" width="10%" class="user-avatar"></a>
                </td>
                <td>
                    <p class="user-title"></p>
                    <p class="user-title"><?php echo $username ?>..</p>
                    <p class="user-email"><?php echo $useremail ?></p>
                </td>
            </tr>
            <tr>
				<td>
				<div class="col-xl-3 col-lg-4 col-6 top-w3layouts p-md-0 text-right">
    <!-- login --><div id="logo">
        
    </div>
    <a href="index.php" class="login-button-2 text-uppercase text-bl">
        <span class="fa fa-sign-in mr-2"></span>Home
    </a>
    <!-- //login -->
    
</div>

				</td>
                <td colspan="2">
                    <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                </td>
				
				
				


				
            </tr>
        </table>
    </td>
    <td style="padding:10px">
        <!-- Rest of the code -->
    </td>
</tr>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- //top header -->

		<!-- second header -->
		<div class="main-top">
			<div class="container">
				<div class="header d-md-flex justify-content-between align-items-center py-3">
					<!-- logo -->
					<div id="logo">
						<h1>
							<a href="indexx.php">
								<span class="fa fa-user-md mr-2"></span>
								<span class="logo-sp">HeLiX</span> MANGMENT SYSTEM
							</a>
						</h1>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu">
								<li><a href="indexx.php">Home</a></li>
								<li class="mx-lg-4 mx-md-3 my-md-0 my-2"><a href="about.php">About Us</a></li>
								<li><a href="gallery.php">Gallery</a></li>
								<li class="mx-lg-4 mx-md-3 my-md-0 my-2">
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#" class="active">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="about.php" class="drop-text">Services</a></li>
										<li><a href="index.php" class="drop-text">Blog</a></li>
										<li><a href="single.php" class="drop-text active">Blog Details</a></li>
										<li><a href="index.php" class="drop-text">What We do</a></li>
										<li><a href="about.php" class="drop-text">Our Doctors</a></li>
									</ul>
								</li>
								<li><a href="contact.php">Contact Us</a></li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</div>
		<!-- //second header -->

		<!-- banner -->
		<div class="main-banner-2">

		</div>
		<!-- //banner -->
	</div>
	<!-- //main -->

	<!-- page details -->
	<div class="breadcrumb-agile py-1">
		<ol class="breadcrumb m-0">
			<li class="breadcrumb-item">
				<a href="indexx.html">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">Blog Details</li>
		</ol>
	</div>
	<!-- //page details -->

	<!-- single -->
	<div class="blog-w3l py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="title-section mb-sm-5 mb-4">
				<h6 class="w3ls-title-sub">Some More</h6>
				<h3 class="w3ls-title text-uppercase text-dark font-weight-bold">Blog Details</h3>
			</div>
			<div class="blog_section px-lg-5">
				<div class="card border-0">
					<a href="sngle.php">
						<img src="images/single.jpg" alt="" class="img-fluid">
					</a>
					<div class="card-body p-0 py-4">
						<div class="row border-bottom pb-3">
							<div class="col-sm-6 col-4 perso-wthree">
								<h6 class="blog-first text-bl">
									<span class="fa fa-user mr-2"></span>Adrian Lie
								</h6>
							</div>
							<div class="col-sm-6 col-8 info-commt text-right">
								<ul class="blog_list">
									<li>Jan 16, 2019</li>
									<li class="mx-3">
										<a href="#">
											<span class="fa fa-heart-o mr-1"></span>30
										</a>
									</li>
									<li>
										<a href="#">
											<span class="fa fa-comments-o mr-1"></span>18
										</a>
									</li>
								</ul>
							</div>
						</div>
						<a href="single.php" class="text-bl font-weight-bold blog-grid-title mt-4 mb-3">Proper right way to recharge
							your body</a>
						<p class="card-text">Morbi eget dui elit. In lectus eros, convallis vel dolor vitae, semper sodales risus. Donec
							convallis maximus neque
							vel cursus.</p>
					</div>
				</div>
				<a href="single.php" class="single-text text-bl font-weight-light my-3">Nemo enim ipsam voluptatem quia
					voluptas
					sit aspernatur aut odit aut fugit 2018</a>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore et
					dolore magna
					aliqua uta enim ad minim ven iam quis nostrud exercitation ullamco labor nisi ut aliquip exea commodo
					consequat
					duis
					aute irudre dolor in elit sed uta labore dolore reprehender</p>
				<p class="my-3">Ullamco labor nisi ut aliquip exea commodo consequat duis aute irudre dolor in elit sed uta
					labore dolore reprehender</p>
				<p>Jabore et dolore magna aliqua uta enim ad minim ven iam quis nostrud exercitation ullamco labor nisi utaliquip
					exea commodo consequat duis aute irudre dolor in elit sed uta labore dolore
					reprehender.
				</p>
				<a href="single.php" class="text-bl font-weight-bold blog-grid-title mt-4 mb-3">Two Column Text Sample</a>
				<div class="row">
					<div class="col-md-6">
						<p>Morbi eget dui elit in lectus eros, convallis vel dolor vitae, semper sodales risus. Donec
							convallis maximus neque
							vel cursus.</p>
					</div>
					<div class="col-md-6">
						<p>In lectus eros, convallis vel dolor vitae, semper sodales risus. Donec
							convallis maximus neque
							vel cursus.</p>
					</div>
				</div>
				<a href="single.php" class="single-text text-bl font-weight-light mt-4">Nemo enim ipsam voluptatem quia
					voluptas sit aspernatur aut odit aut fugit 2019</a>
				<p class="my-3">Ullamco labor nisi ut aliquip exea commodo consequat duis aute irudre dolor in elit sed uta
					labore dolore reprehender</p>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore et
					dolore magna
					aliqua uta enim ad minim ven iam quis nostrud exercitation ullamco labor nisi ut aliquip exea commodo
					consequat
					duis
					aute irudre dolor in elit sed uta labore dolore reprehender</p>
				<div class="comment-top mt-5">
					<h4>Comments</h4>
					<div class="media">
						<img src="images/te1.jpg" alt="" class="img-fluid" />
						<div class="media-body pt-xl-2 pl-3">
							<h5 class="mb-2">Joseph Goh</h5>
							<p>Lorem Ipsum convallis diam consequat magna vulputate malesuada. id dignissim sapien velit id felis ac
								cursus eros.
								Cras a ornare elit.</p>
						</div>
					</div>
					<div class="media mt-5">
						<img src="images/te2.jpg" alt="" class="img-fluid" />
						<div class="media-body  pt-xl-2 pl-3">
							<h5 class="mb-2">Goh James</h5>
							<p>Lorem Ipsum convallis diam consequat magna vulputate malesuada. id dignissim sapien velit id felis ac
								cursus eros.
								Cras a ornare elit.</p>
						</div>
					</div>
				</div>
				<div class="comment-top mt-5">
					<h4>Leave a Comment</h4>
					<div class="comment-bottom agileinfo_mail_grid_right">
						<form action="#" method="post">
							<div class="form-group">
								<input class="form-control" type="text" name="Name" placeholder="Name" required="">
							</div>
							<div class="form-group">
								<input class="form-control" type="email" name="Email" placeholder="Email" required="">
							</div>
							<div class="form-group">
								<input class="form-control" type="text" name="Subject" placeholder="Subject" required="">
							</div>
							<div class="form-group">
								<textarea class="form-control" name="Message" placeholder="Message..." required=""></textarea>
							</div>
							<button type="submit" class="btn submit mt-4"onclick="submitForm()">Submit</button>
						</form>
					</div>
				</div>
				<script>
  function submitForm() {
    // Display an alert message
    alert('Message submitted!');
  }
</script>
			</div>
		</div>
	</div>
	
	<!-- //single -->


	<!-- footer -->
	<footer class="py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-7 w3l-footer">
					<!-- logo -->
					<div class="logo2">
						<h2>
							<a href="indexx.php">
								<span class="fa fa-user-md mr-2"></span>
								<span class="logo-sp">HeLiX</span> MANGMENT SYSTEM
							</a>
						</h2>
					</div>
					<!-- //logo -->
					<p class="mt-4 text-li">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
						laudantium, totam rem
						aperiam,
						eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
					<ul class="list-unstyled list-styles mt-lg-5 mt-4">
						<li>
							<p class="text-li"><span class="fa fa-location-arrow mr-2"></span>Lebanon, Beirut</p>
						</li>
						<li class="my-3">
							<p class="text-li"><span class="fa fa-phone mr-2"></span>+961</p>
						</li>
						<li>
							<a href="mailto:info@example.com" class="text-wh"><span class="fa fa-envelope-open mr-2"></span>karim.borshalli1998@gmail.com</a>
						</li>
					</ul>
				</div>
				<div class="col-lg-5 w3l-footer mt-lg-0 mt-5">
					<h3 class="mb-sm-4 mb-3 text-wh">Partners</h3>
					<ul class="list-unstyled list-part text-wh pt-lg-3">
						<li><span class="fa fa-500px" aria-hidden="true"></span></li>
						<li class="mx-4"><span class="fa fa-gg" aria-hidden="true"></span></li>
						<li><span class="fa fa-lastfm" aria-hidden="true"></span></li>
						<li class="mx-4"><span class="fa fa-openid" aria-hidden="true"></span></li>
						<li><span class="fa fa-angellist" aria-hidden="true"></span></li>
					</ul>
					
				</div>
			</div>
		</div>
	</footer>
	<!-- //footer -->

	<!-- footer bottom -->
	<!-- copyright -->
	<div class="copy-w3pvt">
		<div class="container py-3">
			<div class="row">
				<div class="col-lg-7 w3ls_footer_grid1_left text-lg-left text-center">
					<p>&copy; 2023 HeLiX MANGMENT SYSTEM. All rights reserved | Design by
						<a href="#">Karim Borshalli</a>
					</p>
				</div>
				<div class="col-lg-5 w3ls_footer_grid_left1_pos text-lg-right text-center mt-lg-0 mt-2">
				<ul>
						<li>
							<a href="https://www.facebook.com/karim.borshalli/" class="facebook">
								<span class="fa fa-facebook-f mr-2"></span>Facebook</a>
						</li>
						<li class="mx-3">
							<a href="https://www.instagram.com/karimborshalli/" class="instagram">
								<span class="fa fa-instagram mr-2"></span>Instagram</a>
						</li>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- //copyright -->
	<!-- //footer bottom -->
	<!-- move top icon -->
	<a href="#home" class="move-top text-center"></a>
	<!-- //move top icon -->

</body>

</html>