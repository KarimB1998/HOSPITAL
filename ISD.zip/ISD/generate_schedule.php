<?php
// import database
include("connection.php");

// Define the session names
//$sessionNames = array("Check Up", "Review", "Surgery");

$sessionData = array(
    array("title" => "Check Up", "nop" => 3),
    array("title" => "Review", "nop" => 5),
    array("title" => "Surgery", "nop" => 1)
);
$docids = array(1, 2, 3, 4, 5, 6, 7, 8);

// Define the date range for generating schedule records (e.g., 30 days)
$start_date = date("Y-m-d");
$end_date = date('Y-m-d', strtotime($start_date . ' + 30 days'));

// Generate and execute the insert query for each date
$current_date = $start_date;
while ($current_date <= $end_date) {
    foreach ($docids as $docid) {
    //$title = $sessionNames[array_rand($sessionNames)];
    foreach ($sessionData as $session) {
        $title = $session["title"];
        $nop = $session["nop"];
    $scheduledate = $current_date;
    $scheduletime = generateRandomTime();
    

    $insertQuery = "INSERT INTO `schedule` (`docid`, `title`, `scheduledate`, `scheduletime`, `nop`)
                    VALUES ($docid, '$title', '$scheduledate', '$scheduletime', $nop)";
    $database->query($insertQuery);
    }
}
    $current_date = date('Y-m-d', strtotime($current_date . ' + 1 day'));
}

// Function to generate a random time (you can customize this function)
function generateRandomTime() {
    $hours = str_pad(rand(6, 17), 2, "0", STR_PAD_LEFT);
    $minutes = str_pad(rand(0, 59), 2, "0", STR_PAD_LEFT);
    return $hours . ":" . $minutes;
}



?>