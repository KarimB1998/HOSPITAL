<?php


    $database= new mysqli("localhost","root","","isd");
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>