// Wait for the document to load
document.addEventListener('DOMContentLoaded', function() {
    // Get the services box element
    const servicesBox = document.querySelector('.services-box');
  
    // Add click event listener to the services box
    servicesBox.addEventListener('click', function() {
      // Perform an action when the services box is clicked
      console.log("Services box clicked!");
  
      // You can add your desired functionality here
      // For example, you can redirect to another page:
      // window.location.href = "about.php";
    });
  });

  // Wait for the document to load
document.addEventListener('DOMContentLoaded', function() {
    // Get the logo element
    const logo = document.getElementById('logo');
  
    // Add a click event listener to the logo
    logo.addEventListener('click', function() {
      // Perform an action when the logo is clicked
      console.log("Logo clicked!");
  
      // You can add your desired functionality here
      // For example, you can change the text or apply styles to the logo
      // logo.textContent = "New Logo Text";
      // logo.style.color = "red";
    });
  });
  
  
  
  
