
document.addEventListener('DOMContentLoaded', function() {
    var intervalTime = 5000;    
    var slides = document.getElementsByName('slides');    
    var totalSlides = slides.length;   
    var currentSlide = 0;
    
    function changeSlide() {
      slides[currentSlide].checked = false;      
      currentSlide = (currentSlide + 1) % totalSlides;      
      slides[currentSlide].checked = true;
    }
    
    setInterval(changeSlide, intervalTime);
  });

 


 
  
  